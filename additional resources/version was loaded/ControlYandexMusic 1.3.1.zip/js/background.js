chrome.commands.onCommand.addListener(function(command) {
    let cmd = command;
    switch (cmd) {
        case 'next-key':
            sendEvent('next', true);
            break;
        case 'previous-key':
            sendEvent('previous', true);
            break;
        case 'play-key':
            sendEvent('pause', true);
            break;
        case 'like-key':
            sendEvent('like', true);
            break;
    }
});

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if (request.backgroundMessage == "background") {
            setNotifications(request.name, request.artists, request.imageUrl);
        }
        if (request.loading == true) {
            firstLoad(request.activeTab);
        }
    });

let firstLoad = (activeTab) => {
    chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
        if (changeInfo.status == 'complete') {
            sendFirstLoad(tab.id);
        }
    });
}

function sendEvent(event, isKey) {
    let activeTab;
    chrome.tabs.query({ windowType: "normal" }, function(tabs) {
        for (let i = tabs.length - 1; i >= 0; i--) {
            if (tabs[i].url.startsWith("https://music.yandex")) {
                activeTab = tabs[i].id;
                break;
            }
        }
        chrome.tabs.sendMessage(activeTab, { data: event, key: isKey });
    });
}

function sendFirstLoad(activeTab) {
    chrome.runtime.sendMessage({ uploaded: true, activeTab: activeTab });

}

function setNotifications(trackTitle, trackArtists, iconTrack) {
    if (iconTrack == undefined) {
        iconTrack = "img/iconY.png"
    }
    chrome.notifications.create("YandexMusicControl", { type: "basic", eventTime: 700.0, title: trackTitle, message: trackArtists, iconUrl: iconTrack }, function(callback) {
        timer = setTimeout(function() { chrome.notifications.clear("YandexMusicControl"); }, 7000);

    }); {}
}