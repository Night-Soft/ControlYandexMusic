var a = document.getElementsByClassName("donationalerts")[0];
document.getElementsByClassName("paypal")[0].onclick = function() { window.open("https://www.paypal.com/paypalme2/NightSoftware") };
a.onclick = function() { window.open("https://www.donationalerts.com/r/nightsoftware") };