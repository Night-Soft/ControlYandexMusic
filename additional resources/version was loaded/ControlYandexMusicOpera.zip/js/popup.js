var _gaq = _gaq || [];
_gaq.push(["_setAccount", "UA-150296887-1"]);
_gaq.push(["_trackPageview"]);
(function() {
    var a = document.createElement("script");
    a.type = "text/javascript";
    a.async = !0;
    a.src = "https://ssl.google-analytics.com/ga.js";
    var b = document.getElementsByTagName("script")[0];
    b.parentNode.insertBefore(a, b)
})();