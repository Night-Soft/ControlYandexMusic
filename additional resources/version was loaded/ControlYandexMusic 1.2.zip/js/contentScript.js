chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.btn == true) { isBtn = true }
    if (request.key == true) { isKey = true }
    switch (request.data) {
        case 'previous':
            setPrevious();
            break;
        case 'pause':
            setPause();
            break;
        case 'next':
            setNext();
            break;
        case 'event':
            break;
        case 'extensionIsLoad':
            getLike();
            getNameTrack();
            sendToPopup();
            break;
        case 'getPause':
            getPause();
            break;
        case 'like':
            getLike();
            setLike();
            break;
        default:
            break;
    }
});

function setPrevious() {
    let previousTarget = document.getElementsByClassName("player-controls__btn_prev");
    let seconds = document.getElementsByClassName("progress__left")[0];
    seconds = seconds.innerHTML.slice(2, 4);
    previousTarget[0].click();
    if (seconds >= 3) {
        let updater = setTimeout(function() {
            previousTarget[0].click();
        }, 100);
    }
    updateNameTrack();
}

function setPause() {
    let pauseTarget = document.getElementsByClassName("deco-player-controls__button player-controls__btn_play");
    pauseTarget[0].click();
    sendMsgPause();


}

function setNext() {
    let nextTarget = document.getElementsByClassName("player-controls__btn_next");
    nextTarget[0].click();
    updateNameTrack();
}

let nameTrack = "isEmpty";
let nameArtists = ""
let trackTitleNext = document.getElementsByClassName("track__title");
let progressLeft = document.getElementsByClassName("progress__left");
let i = 0;

function getPause() {
    i++;
    let btnPause = document.getElementsByClassName("player-controls__btn_pause")[0];
    if (btnPause == undefined) {
        chrome.runtime.sendMessage({
            btnPause: "isFalse"
        });

    }
    if (btnPause != undefined) {
        chrome.runtime.sendMessage({
            btnPause: "isTrue"
        }, function(response) {

        });
    }

}

let isKey = false;
let isBtn = false;
let likes = false;

function setLike() {
    let like = document.getElementsByClassName("d-like_theme-player")[0];

    like = like.childNodes[0];
    like.click();
    if (likes == true) {
        sendLike(false);
    } else {
        sendLike(true);

    }
}

function sendLike(isLike) {
    chrome.runtime.sendMessage({ like: isLike });
}

function getLike(isLike) {
    let like = document.getElementsByClassName("d-like_theme-player")[0];
    like = like.childNodes[0];
    if (like.classList.contains("d-icon_heart-full")) {
        isLike = true;
        likes = true;
        sendLike(isLike);
    } else {
        isLike = false;
        likes = false;
        sendLike(isLike);
    }
}

function updateNameTrack() {
    let trackTitle = document.getElementsByClassName("track__title");
    nameTrack = trackTitle[0].innerHTML;
    let trackUpdate = document.getElementsByClassName("track__title");

    function startUpdate() {
        return new Promise(resolve => {
            setTimeout(() => {
                trackUpdate = document.getElementsByClassName("track__title");
                if (trackUpdate[0].innerHTML != nameTrack) {
                    nameTrack = trackUpdate[0].innerHTML;
                    resolve('resolved');
                } else {
                    asyncCall();
                }

            }, 700);
        });

    }
    async function asyncCall() {
        var result = await startUpdate();
        if (isBtn == true) {
            sendToPopup();
            isBtn = false;
        }
        if (isKey == true) {
            sendMsg();
            isKey = false;
        }

    }
    asyncCall();

}

function getNameTrack() {
    nameArtists = "";
    let trackTitle = document.getElementsByClassName("track__title");
    nameTrack = trackTitle[0].innerHTML;
    let artists = document.getElementsByClassName("d-artists__expanded");
    let textArtist = artists[0].childNodes;
    for (let i = 0; i <= textArtist.length - 1; i++) {
        if (textArtist[i].text != undefined) {
            nameArtists += textArtist[i].text;
        }
        if (textArtist.length >= 1 && textArtist[i].text != undefined && i != textArtist.length - 1) {
            nameArtists += ", ";

        }

    }

}

let imgTrack;

function getTrackImg() {
    let getImg = document.getElementsByClassName("track_type_player");
    let imgFirst = getImg[0].childNodes;
    let imgTwo;
    let imgThree;
    imgTwo = imgFirst[0].childNodes;
    imgThree = imgTwo[0].childNodes;
    for (let i = 0; i <= imgThree.length - 1; i++) {
        imgTrack = imgThree[i].src;
    }
}

function sendMsg() {
    getNameTrack();
    getPause();
    getTrackImg();
    chrome.runtime.sendMessage({ backgroundMessage: "background", name: nameTrack, artists: nameArtists, imageUrl: imgTrack });
    chrome.runtime.sendMessage({ popupMessage: "popup", name: nameTrack, artists: nameArtists, imageUrl: imgTrack });
}

function sendMsgPause() {
    getNameTrack();
    getTrackImg();
    chrome.runtime.sendMessage({ backgroundMessage: "background", name: nameTrack, artists: nameArtists, imageUrl: imgTrack });
}

function sendToPopup() {
    getNameTrack();
    getTrackImg();
    getPause();
    getLike();
    chrome.runtime.sendMessage({ popupMessage: "popup", name: nameTrack, artists: nameArtists, imageUrl: imgTrack });
}