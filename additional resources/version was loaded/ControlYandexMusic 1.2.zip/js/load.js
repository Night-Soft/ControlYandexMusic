console.time("load time");

window.addEventListener('load', (event) => {
    console.timeEnd("load time");

});