var extensionId = "bhcfibiihpkamomgolcmafcblbaonlka";
var port = chrome.runtime.connect(extensionId);
window.addEventListener("message", function(event) {
    if (event.source != window)
        return;

    switch (event.data.function) {
        case 'getCurrentTrack':
            getTracks();
            break;
        case 'togglePause':
            togglePause();
            break;
        case 'getControls':

            break;
        case 'previous':
            previous();
            break;
        case 'next':
            next();
            break;
        case 'next':
            next();
            break;
        case 'toggleLike':
            toggleLike();
            break;
        default:
            break;
    }
    switch (event.data.commandKey) {
        case 'previous-key':
            previousKey();
            break;
        case 'togglePause-key':
            togglePauseKey();
            break;
        case 'next-key':
            nextKey();
            break;
        case 'toggleLike-key':
            toggleLikeKey();
            break;
    }
}, false);
// externalAPI.on(externalAPI.EVENT_TRACK, function(event) {
//     console.log("Event track");

// })

function getTracks() {

    chrome.runtime.sendMessage(extensionId, {
        data: "currentTrack",
        api: externalAPI.getCurrentTrack(),
        isPlaying: externalAPI.isPlaying(),
        //getControls: externalAPI.getControls()
    }, );
}

function next() {
    let promise = externalAPI.next();
    promise.then(function() {
        getTracks();
    });
}

function sendTest() {
    window.postMessage({
        type: "FROM_PAGE",
        text: "Hello from the webpage!"
    }, "*");
}

function previous() {
    let promise = externalAPI.prev();
    promise.then(function() {
        getTracks();
    });

}

function getControls() {
    chrome.runtime.sendMessage(extensionId, {
        data: "getControls",
        api: externalAPI.getControls()
    }, );

}

function togglePause() {
    externalAPI.togglePause();
    chrome.runtime.sendMessage(extensionId, {
        data: "togglePause",
        isPlaying: externalAPI.isPlaying()
    }, );
}

function toggleLike() {
    externalAPI.toggleLike();
    chrome.runtime.sendMessage(extensionId, {
        data: "toggleLike",
        isLiked: externalAPI.getCurrentTrack()
    });
}
let previousKey = () => {
    let promise = externalAPI.prev();
    promise.then(
        function() {
            chrome.runtime.sendMessage(extensionId, {
                key: "key",
                dataKey: "previous-key",
                currentTrack: externalAPI.getCurrentTrack()
            });
            getTracks();

        });
}
let togglePauseKey = () => {
    externalAPI.togglePause();
    chrome.runtime.sendMessage(extensionId, {
        key: "key",
        dataKey: "togglePause-key",
        currentTrack: externalAPI.getCurrentTrack()
    });
    getTracks();

}
let nextKey = () => {
    let promise = externalAPI.next();
    promise.then(function() {
        chrome.runtime.sendMessage(extensionId, {
            key: "key",
            dataKey: "next-key",
            currentTrack: externalAPI.getCurrentTrack()
        });
        getTracks();
    });
}
let toggleLikeKey = () => {
    externalAPI.toggleLike();
    chrome.runtime.sendMessage(extensionId, {
        key: "key",
        dataKey: "toggleLike-key",
        currentTrack: externalAPI.getCurrentTrack()
    });
    getTracks();

}