var _gaq = _gaq || [];
_gaq.push(["_setAccount", "UA-150296887-1"]);
_gaq.push(["_trackPageview"]);
(function() {
    var a = document.createElement("script");
    a.type = "text/javascript";
    a.async = !0;
    a.src = "https://ssl.google-analytics.com/ga.js";
    var b = document.getElementsByTagName("script")[0];
    b.parentNode.insertBefore(a, b)
})();
var pushEvent = function(a) { _gaq.push(["_trackEvent", a, "background"]) };
chrome.commands.onCommand.addListener(function(a) {
    switch (a) {
        case "next-key":
            pushEvent(a);
            sendEvent("next", !0);
            break;
        case "previous-key":
            pushEvent(a);
            sendEvent("previous", !0);
            break;
        case "play-key":
            pushEvent(a), sendEvent("pause", !0)
    }
});
chrome.runtime.onMessage.addListener(function(a, b, c) { "background" == a.backgroundMessage && setNotifications(a.name, a.artists, a.imageUrl) });

function sendEvent(a, b) {
    var c;
    chrome.tabs.query({ windowType: "normal" }, function(e) {
        for (var d = e.length - 1; 0 <= d; d--)
            if (e[d].url.startsWith("https://music.yandex")) { c = e[d].id; break }
        chrome.tabs.sendMessage(c, { data: a, key: b }, function(a) {})
    })
}

function setNotifications(a, b, c) {
    void 0 == c && (c = "img/iconY.png");
    chrome.notifications.create("YandexMusicControl", { type: "basic", eventTime: 700, title: a, message: b, iconUrl: c }, function(a) { timer = setTimeout(function() { chrome.notifications.clear("YandexMusicControl") }, 7E3) })
};