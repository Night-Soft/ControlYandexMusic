var previous = document.getElementsByClassName("previous"),
    pause = document.getElementsByClassName("pause"),
    next = document.getElementsByClassName("next"),
    title = document.getElementsByClassName("title"),
    trackName = document.getElementsByClassName("name-track"),
    aritstName = document.getElementsByClassName("name-artists"),
    trackImg = document.getElementsByClassName("cover"),
    modal = document.getElementsByClassName("modal"),
    modalCover = document.getElementsByClassName("modal-cover"),
    like = document.getElementsByClassName("like"),
    container = document.getElementsByClassName("container")[0],
    containerMenu = document.getElementsByClassName("content-menu")[0],
    modalSide = document.getElementsByClassName("modal-side")[0],
    contactMe = document.getElementById("contactMe"),
    about = document.getElementsByClassName("side")[0],
    shortCuts = document.getElementsByClassName("side")[2],
    supportMenu = document.getElementsByClassName("support-menu")[0],
    closeSide = document.getElementsByClassName("close-side")[0],
    aMenu = document.getElementsByTagName("a")[0],
    payPal =
    document.getElementsByClassName("paypal-menu")[0],
    donationAlerts = document.getElementsByClassName("donationalerts-menu")[0],
    sideHelp = document.getElementsByClassName("side-help")[0],
    statePlay = !1,
    isBarOpen = !1,
    i = 0,
    addAnimListener = function() { 1 == isBarOpen && containerMenu.addEventListener("animationend", endAnimation) },
    endAnimation = function() {
        modalSide.style.display = "none";
        isBarOpen = !1;
        containerMenu.removeEventListener("animationend", endAnimation)
    },
    toggleMenu = function() {
        container.classList.toggle("change");
        0 == isBarOpen ? (containerMenu.style.display = "flex", modalSide.style.display = "block", modalSide.style.opacity = "1", containerMenu.className = containerMenu.className.replace(" slide-out", " slide-right"), isBarOpen = !0) : (containerMenu.className = containerMenu.className.replace(" slide-right", " slide-out"), modalSide.style.opacity = "0", addAnimListener())
    };
document.addEventListener("DOMContentLoaded", function() {
    sendEvent("extensionIsLoad");
    sendEvent("getPause");
    pushEvent("Extension Loaded", "loaded");
    container.onclick = function() { toggleMenu() };
    previous[0].addEventListener("click", function() {
        sendEvent("previous", !0);
        pushEvent(previous[0].className, "clicked")
    });
    pause[0].addEventListener("click", function() {
        sendEvent("pause");
        changeState();
        pushEvent(pause[0].className, "clicked")
    });
    next[0].addEventListener("click", function() {
        sendEvent("next", !0);
        pushEvent(next[0].className,
            "clicked")
    });
    trackImg[0].addEventListener("click", function() { openCover() });
    modal[0].onclick = function() { modal[0].style.display = "none" };
    like[0].onclick = function() {
        sendEvent("like");
        pushEvent(like[0].className, "clicked")
    };
    shortCuts.onclick = function() { chrome.tabs.create({ url: "chrome://extensions/shortcuts" }) };
    contactMe.onclick = function() { window.open("mailto:support@night-software.cf") };
    aMenu.onclick = function() { window.open("mailto:support@night-software.cf") };
    closeSide.onclick = function() { toggleMenu() };
    about.onclick = function() {
        chrome.tabs.create({ url: "about.html" });
        pushEvent(about.className)
    };
    supportMenu.onclick = function() {};
    payPal.onclick = function() {
        pushEvent("payPal");
        window.open("https://www.paypal.com/paypalme2/NightSoftware")
    };
    donationAlerts.onclick = function() {
        pushEvent("donationAlerts");
        window.open("https://www.donationalerts.com/r/nightsoftware")
    };
    sideHelp.onmouseenter = function(a) {
        payPal.style.display = "block";
        donationAlerts.style.display = "block"
    };
    sideHelp.onmouseleave = function() {
        payPal.style.display =
            "none";
        donationAlerts.style.display = "none"
    }
});
chrome.runtime.onMessage.addListener(function(a, c, b) {
    "popup" == a.popupMessage && setMediaData(a.name, a.artists, a.imageUrl);
    "isTrue" == a.btnPause && (statePlay = !0, changeState());
    "isFalse" == a.btnPause && (statePlay = !1, changeState());
    1 == a.like && setLike(a.like);
    0 == a.like && setLike(a.like)
});

function sendEvent(a, c) {
    var b;
    chrome.tabs.query({ windowType: "normal" }, function(d) {
        for (var e = d.length - 1; 0 <= e; e--)
            if (d[e].url.startsWith("https://music.yandex")) { b = d[e].id; break }
        chrome.tabs.sendMessage(b, { data: a, btn: c }, function(a) {})
    })
}
var urlCover, pushEvent = function(a, c) { _gaq.push(["_trackEvent", a, c]) };

function setMediaData(a, c, b) {
    aritstName[0].innerHTML = c;
    trackName[0].innerHTML = a;
    b.endsWith(".svg") ? b = "img/icon.png" : (b = b.slice(0, -5), urlCover = b += "200x200");
    trackImg[0].style.backgroundImage = "url(" + b + ")"
}

function changeState() { 0 == statePlay ? (pause[0].style.backgroundImage = "url(img/play.png)", pause[0].style.backgroundPosition = "26px center", pause[0].style.backgroundSize = "46px", statePlay = !0) : (pause[0].style.backgroundImage = "", pause[0].style.backgroundPosition = "", pause[0].style.backgroundSize = "", statePlay = !1) }

function setLike(a) { like[0].style.backgroundImage = 1 == a ? "url(img/like.png)" : "url(img/unLike.png)" }

function openCover() {
    function a() {
        var a = new XMLHttpRequest;
        a.onreadystatechange = function() { b = this.status };
        a.open("post", urlCover, !1);
        a.send()
    }
    var c = 400,
        b = 0;
    urlCover = urlCover.slice(0, -7);
    for (var d = 3; 0 <= d && (urlCover += c + "x" + c, a(), 200 != b); d--) {
        if (100 == c) { c += -50; break }
        c += -100
    }
    modalCover[0].style.backgroundImage = "url(" + urlCover + ")";
    modalCover[0].src = urlCover;
    var e = setInterval(function() {
            f++;
            999 == f && g++;
            modalCover[0].onload = function() {
                clearInterval(e);
                modal[0].style.display = "flex"
            }
        }, 1),
        f = 0,
        g = 0
};